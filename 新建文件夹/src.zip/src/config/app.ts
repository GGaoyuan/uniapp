export const APP_NAME = '';
export const APP_ID = '';
export const APP_VERSION = '';
