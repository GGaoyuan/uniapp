declare namespace Types {
  type Query = {
    replace?: boolean
    [propName: string]: any
  }
}
