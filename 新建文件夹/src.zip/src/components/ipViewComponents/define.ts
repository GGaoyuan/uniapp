import type { System } from '@/@types/types';

export function defineSystem(fn: System) {
    return fn;
}
  